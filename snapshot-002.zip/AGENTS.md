# 项目协作与 GitHub 同步

用户于 2026-10-11 明确要求：在 lianggeming14 账号建立仓库，把项目文件上传，以后生成的文件也同步一份。此约定适用于本项目目录，持续有效。

- 目标仓库：https://github.com/lianggeming14/liangzihu-ontology-traceability
- 默认分支：main；维持私有可见性，未经用户明确要求不要公开。
- 使用当前会话模型实施；Kimi 已按用户指示退出。
- 每轮产生或修改项目成果后，在交付前检查并同步 GitHub：方案、代码、测试、契约、生成脚本、图片、预览及交付包都属于同步范围。
- 遵守根目录和 implementation/.gitignore；访问令牌、密码、认证缓存、依赖、活动数据库及原始运行资产不能因为“全部上传”而进入仓库。合成示例由 seed.py 重建。
- 正常网络环境优先运行 tools/sync_to_github.py；推送前运行相关检查，扫描新增文件，处理远端新增提交，不强制覆盖或 force push。
- 若 Git 网络不可达，可通过已登录 GitHub 网页上传经过校验的快照分卷，再手动运行 Import reviewed project snapshot 工作流。参考 GITHUB_SYNC.txt。不得读取或复制浏览器 cookie/凭据来绕过认证。
- 同步后核对远端提交/文件；失败时保留本地成果并明确报告未同步部分，不声称已上传。
- 本要求是每次项目交付时执行同步，不表示存在后台文件监听、系统定时任务或任何自动运行服务。
- 本地 SQLite 测试不替代 PostgreSQL 实库与现场验收；报告必须保留通过/失败/跳过及数据性质的区分。
